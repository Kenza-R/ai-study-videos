# Social media video generator for papers

Run with a pubmed id or pubmed central id like this


```
uv run python main.py generate-video PMC10979640 tmp/PMC10979640
```

You need a gemini API key and a runwayML api key. Good luck!
AI can help you edit/run this code.
